## Sensu-Plugins-Flapjack

## Functionality

## Files
 * bin/handler-flapjack.rb

## Usage
```
{
  "flapjack": {
    "host": "localhost",
    "port": 6379,
    "db": "0"
  }
}
```
## Installation

[Installation and Setup](https://github.com/sensu-plugins/documentation/blob/master/user_docs/installation_instructions.md)

## Notes
