#Change Log
This project adheres to [Semantic Versioning](http://semver.org/).

This CHANGELOG follows the format listed at [Keep A Changelog](http://keepachangelog.com/)

## Unreleased][unreleased]

## 0.0.1 - 2016-06-01

### Added
- initial release

