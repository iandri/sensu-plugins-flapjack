require 'sensu-plugins-flapjack/version'
